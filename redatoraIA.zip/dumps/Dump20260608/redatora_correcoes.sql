CREATE DATABASE  IF NOT EXISTS `redatora` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `redatora`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: redatora
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '246b9181-c3dd-11f0-b090-d09466e7585f:1-25400';

--
-- Table structure for table `correcoes`
--

DROP TABLE IF EXISTS `correcoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `correcoes` (
  `id_correcao` int NOT NULL AUTO_INCREMENT,
  `id_redacao` int DEFAULT NULL,
  `nota_c1` int DEFAULT NULL,
  `nota_c2` int DEFAULT NULL,
  `nota_c3` int DEFAULT NULL,
  `nota_c4` int DEFAULT NULL,
  `nota_c5` int DEFAULT NULL,
  `nota_total` int GENERATED ALWAYS AS (((((`nota_c1` + `nota_c2`) + `nota_c3`) + `nota_c4`) + `nota_c5`)) STORED,
  `feedback_c1` text,
  `feedback_c2` text,
  `feedback_c3` text,
  `feedback_c4` text,
  `feedback_c5` text,
  `pontos_fortes` text,
  `pontos_fracos` text,
  `sugestoes` text,
  `data_correcao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_correcao`),
  KEY `id_redacao` (`id_redacao`),
  CONSTRAINT `correcoes_ibfk_1` FOREIGN KEY (`id_redacao`) REFERENCES `redacoes` (`id_redacao`),
  CONSTRAINT `correcoes_chk_1` CHECK ((`nota_c1` between 0 and 200)),
  CONSTRAINT `correcoes_chk_2` CHECK ((`nota_c2` between 0 and 200)),
  CONSTRAINT `correcoes_chk_3` CHECK ((`nota_c3` between 0 and 200)),
  CONSTRAINT `correcoes_chk_4` CHECK ((`nota_c4` between 0 and 200)),
  CONSTRAINT `correcoes_chk_5` CHECK ((`nota_c5` between 0 and 200))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `correcoes`
--

LOCK TABLES `correcoes` WRITE;
/*!40000 ALTER TABLE `correcoes` DISABLE KEYS */;
INSERT INTO `correcoes` (`id_correcao`, `id_redacao`, `nota_c1`, `nota_c2`, `nota_c3`, `nota_c4`, `nota_c5`, `feedback_c1`, `feedback_c2`, `feedback_c3`, `feedback_c4`, `feedback_c5`, `pontos_fortes`, `pontos_fracos`, `sugestoes`, `data_correcao`) VALUES (1,1,160,180,160,200,180,'Bom domínio da norma culta','Boa compreensão do tema','Argumentação adequada','Coesão excelente','Boa proposta de intervenção','Boa estrutura textual','Poucos argumentos','Desenvolver mais os exemplos','2026-06-08 18:00:51');
/*!40000 ALTER TABLE `correcoes` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-08 15:08:16
